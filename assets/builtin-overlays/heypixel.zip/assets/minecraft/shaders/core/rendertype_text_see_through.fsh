#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    vec4 color = texColor * vertexColor;

    // 修改为粉色 (1.0, 0.6, 0.8)
    if (color.a < 0.5) {
        fragColor = vec4(1.0, 0.6, 0.8, 0.7); // 粉色，70%透明度
    } else {
        fragColor = color * ColorModulator;
    }
}